﻿namespace UseCaseFinalSubmission.Models
{
    public class LoginResponse
    {
        public string UserName { get; set; }

        public string token { get; set; }
    }
}
