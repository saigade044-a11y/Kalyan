﻿namespace UseCaseFinalSubmission.Models
{
    public class EnrollAndUnEroll
    {

        public int StudentId1 { get; set; }

        public int CourseId1 { get; set; }

    }
}
