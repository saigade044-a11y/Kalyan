﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Text;
using UseCaseFinalSubmission.Database;
using UseCaseFinalSubmission.Models;

namespace UseCaseFinalSubmission.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorizeController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        private readonly Database1 _database;
        public AuthorizeController(IConfiguration configuration,Database1 database)
        {
            _configuration = configuration;
            _database = database;
        }
        [HttpPost]
        [Route("Login")]

        public IActionResult Login([FromBody] LoginRequest1 request)
        {
            var student = _database.Student.FirstOrDefault(n => n.Email == request.UserName && n.Password == request.Password);
            var admin = _database.admin.FirstOrDefault(n => n.UserName == request.UserName && n.Password == request.Password);

            dynamic k = " ";

            if (student != null)
            {
                k = student;

            }
            if (admin != null)
            {
                k = admin;
            }
            else
            {
                return Unauthorized("Invalid UserName or Password");
            }

                var tokenhandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration.GetValue<string>("Key"));
            var tokendescriptor = new SecurityTokenDescriptor()
            {
                Subject = new System.Security.Claims.ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name,request.UserName),
                    new Claim(ClaimTypes.Role,k.Role),

/*                    new Claim("UserName",request.UserName),
                    new Claim("Role",k.Role),
*/
                }),
                Expires=DateTime.UtcNow.AddHours(1),
                SigningCredentials=new SigningCredentials(new SymmetricSecurityKey(key),SecurityAlgorithms.HmacSha256Signature)




            };

            var token = tokenhandler.CreateToken(tokendescriptor);
            LoginResponse obj = new LoginResponse()
            {
                UserName = request.UserName,
                token = tokenhandler.WriteToken(token)
            };
            return Ok(obj);

        }
    }
}
