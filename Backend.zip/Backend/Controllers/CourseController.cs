﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UseCaseFinalSubmission.Database;
using UseCaseFinalSubmission.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UseCaseFinalSubmission.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class CourseController : ControllerBase
    {
        private readonly Database1 database1;

        public CourseController(Database1 database1)
        {
            this.database1 = database1;
        }

        [HttpGet]
        [Route("GetAllCourses")]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<Course>>> GetAllCourses()
        {
            var courses = await database1.Course
                .Include(c => c.Enrollements)
                .Select(c => new
                {
                    c.CourseId,
                    c.CourseName,
                    c.CourseDescription,
                    c.Capacity,
                    EnrolledCount = c.Enrollements.Count(),
                    AvailableSeats = c.Capacity - c.Enrollements.Count()
                }).ToListAsync();

            return Ok(courses);
        }

        [HttpPost]
        [Route("CreateCourse")]
        public async Task<ActionResult<Course>> CreateCourses([FromBody] Course model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (model == null)
                return BadRequest("Invalid Couse Data");

            var courseExists = await database1.Course.AnyAsync(n => n.CourseName.ToLower() == model.CourseName.ToLower());

            if (courseExists)
                return BadRequest("Already The Course Exists");

            model.EnrolledCount = 0;
            model.AvailableSeats = model.Capacity;

            database1.Course.Add(model);
            await database1.SaveChangesAsync();

            return Ok(new { Message = "Course created successfully", Course = model });
        }

        [HttpPut]
        [Route("UpdateCourseById/{id:int}")]
        public async Task<ActionResult<Course>> UpdateCourse([FromBody] Course model, int id)
        {
            if (id <= 0)
                return BadRequest("The Id Value BE Not Less Than Zero");

            var existingcourse = await database1.Course
                .Include(c => c.Enrollements)
                .FirstOrDefaultAsync(n => n.CourseId == id);

            if (existingcourse == null)
                return NotFound("No Course Has Found In It");

            existingcourse.CourseName = model.CourseName;
            existingcourse.CourseDescription = model.CourseDescription;
            existingcourse.Capacity = model.Capacity;
            existingcourse.EnrolledCount = existingcourse.Enrollements.Count();
            existingcourse.AvailableSeats = existingcourse.Capacity - existingcourse.EnrolledCount;

            database1.Course.Update(existingcourse);
            await database1.SaveChangesAsync();

            return Ok(new { Message = "Course updated successfully", Course = existingcourse });
        }

        [HttpDelete]
        [Route("DeleteById/{id:int}")]
        public async Task<ActionResult<Course>> DeleteByCourse(int id)
        {
            if (id <= 0)
                return BadRequest("The Id value is Not Less Than Zero");

            var course = await database1.Course.FirstOrDefaultAsync(n => n.CourseId == id);
            if (course == null)
                return BadRequest("No Course Has Found");

            database1.Remove(course);
            await database1.SaveChangesAsync();

            return Ok(new { Message = "Course deleted successfully", DeletedCourse = course });
        }
    }
}
