﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UseCaseFinalSubmission.Database;
using UseCaseFinalSubmission.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace UseCaseFinalSubmission.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly Database1 database;

        public StudentController(Database1 database)
        {
            this.database = database;
        }

        [HttpPost]
        [Route("StudentRegister")]
        public async Task<ActionResult<Student>> CreateRegister([FromBody] Student student)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var existingUser = await database.Student.FirstOrDefaultAsync(n => n.Email.ToLower() == student.Email.ToLower() || n.Phone.ToLower() == student.Phone.ToLower());

            if (existingUser != null)
            {
                return BadRequest("Already This User Has Present");
            }

            var passwordHasher = new PasswordHasher<Student>();

            string HashPassword = passwordHasher.HashPassword(student, student.Password);

            student.Password = HashPassword;

            database.Student.Add(student);
            await database.SaveChangesAsync();

            return Ok(new
            {
                Message = "Student Regsitered Succesfully",
                Student = new
                {
                    student.StudentId,
                    student.FullName,
                    student.Email,
                    student.Phone,
                    student.Address,
                }
            });
        }



        [HttpPost]
        [Route("LoginStudents")]
        public async Task<ActionResult> LoginStudent([FromBody] StudentLogin student)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

           


            var checking = await database.Student .FirstOrDefaultAsync(n => n.Email == student.UserName);

            if (checking == null)
            {

                return NotFound("Please Check Once And Try Again");

            }

            var passwordhasher = new PasswordHasher<Student>();

            string hashedpassword = passwordhasher.VerifyHashedPassword(checking, checking.Password, student.Password).ToString();
            if (hashedpassword == "Failed")
            {
                return BadRequest("Password Is Incorrect");
            }   

            return Ok(new { Message = "Login successful", Student = checking });
        }



        [HttpGet]
        [Route("SearchByCourse/{CourseName}")]
        public async Task<ActionResult> SearchCourse(string CourseName)
        {
            if (string.IsNullOrWhiteSpace(CourseName))
            {
                return BadRequest("Search KeyWord Cannot Be Empty");

            }
            var checking = await database.Course
                .Include(n => n.Enrollements)
                .Where(n => n.CourseName.Contains(CourseName))
                .Select(n => new
                {
                    n.CourseName,
                    n.CourseId,
                    n.CourseDescription,
                    n.Capacity,
                    EnrolledCount = n.Enrollements.Count(),
                    AvailableSeats = n.Capacity - n.Enrollements.Count()
                }).ToListAsync();

            if (checking == null || checking.Count == 0)
                return NotFound("NO Matching Course is Found");

            return Ok(checking);
        }



        [HttpPost]
        [Route("EnrolleCourse")]
        public async Task<ActionResult> EnrollCourse([FromBody] EnrollAndUnEroll model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var studentdata = await database.Student.FirstOrDefaultAsync(n => n.StudentId == model.StudentId1);
            var coursedata = await database.Course.Include(n => n.Enrollements).FirstOrDefaultAsync(n => n.CourseId == model.CourseId1);

            if (studentdata == null || coursedata == null)
            {
                return BadRequest("The Data Has Not Found");
            }
            int enrolledCount = coursedata.Enrollements.Count();
            int availableSeats = coursedata.Capacity - coursedata.EnrolledCount;

            if (availableSeats <= 0)
                return BadRequest($"Course '{coursedata.CourseName}' is already full.");

            bool alreadyEnrolled = await database.Enrollements.AnyAsync(n => n.StudentId == model.StudentId1 && n.CourseId == model.CourseId1);

            if (alreadyEnrolled)
                return BadRequest("Already Student Enrolled That Course");

            Enrollement obj = new Enrollement()
            {
                StudentId = studentdata.StudentId,
                CourseId = coursedata.CourseId
            };

            database.Enrollements.Add(obj);
            coursedata.EnrolledCount++;
            coursedata.AvailableSeats = coursedata.Capacity - coursedata.EnrolledCount;

            database.Course.Update(coursedata);
            await database.SaveChangesAsync();

            return Ok(new
            {
                Message = $"Student '{studentdata.FullName}' successfully enrolled in '{coursedata.CourseName}'.",
                Course = new
                {
                    coursedata.CourseId,
                    coursedata.CourseName,
                    coursedata.Capacity,
                    coursedata.EnrolledCount,
                    coursedata.AvailableSeats
                }
            });
        }




        [HttpPost]
        [Route("UnEnrolleCourse")]
        public async Task<ActionResult> UnEnrollCourse([FromBody] EnrollAndUnEroll model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var studentdata = await database.Student.FirstOrDefaultAsync(n => n.StudentId == model.StudentId1);
            var coursedata = await database.Course.Include(n => n.Enrollements).FirstOrDefaultAsync(n => n.CourseId == model.CourseId1);

            if (studentdata == null || coursedata == null)
                return BadRequest("The Data Has Not Found");

            var checking = await database.Enrollements.FirstOrDefaultAsync(n => n.StudentId == model.StudentId1 && n.CourseId == model.CourseId1);

            if (checking == null)
                return BadRequest("Student is not enrolled in this course.");

            database.Enrollements.Remove(checking);

            coursedata.EnrolledCount = coursedata.Enrollements.Count() - 1;
            if (coursedata.EnrolledCount <= 0)
                coursedata.EnrolledCount = 0;

            coursedata.AvailableSeats = coursedata.Capacity - coursedata.EnrolledCount;

            database.Course.Update(coursedata);
            await database.SaveChangesAsync();

            return Ok(new
            {
                Message = $"Student '{studentdata.FullName}' successfully unrolled in '{coursedata.CourseName}'.",
                Course = new
                {
                    coursedata.CourseId,
                    coursedata.CourseName,
                    coursedata.Capacity,
                    coursedata.EnrolledCount,
                    coursedata.AvailableSeats
                }
            });
        }




        [HttpGet]
        [Route("MyEnrollements/{StudentId:int}")]
        [AllowAnonymous]
        public async Task<ActionResult> GetMyEnrollements(int StudentId)
        {
            if (StudentId <= 0)
                return BadRequest("The id is Not Less Than The Zero");

            var student = await database.Student
                .Include(n => n.Enrollements)
                .ThenInclude(n => n.course)
                .FirstOrDefaultAsync(n => n.StudentId == StudentId);

            if (student == null)
                return BadRequest("The Student Details Was Not Found");

            var enrollment = student.Enrollements.Select(n => new
            {
                n.course.CourseName,
                n.course.CourseId,
                n.course.Capacity,
                EnrolledCount = n.course.Enrollements.Count(),
                AvailableSeats = n.course.Capacity - n.course.EnrolledCount
            }).ToList();

            if (enrollment.Count == 0)
                return Ok(new { Message = "This student has not enrolled in any courses yet." });

            return Ok(new
            {
                Student = student.FullName,
                TotalCourses = enrollment.Count,
                EnrolledCourses = enrollment
            });
        }




    }
}
