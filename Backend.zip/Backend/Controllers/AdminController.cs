﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using UseCaseFinalSubmission.Database;
using UseCaseFinalSubmission.Models;

namespace UseCase.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly Database1 _context;

        public AdminController(Database1 context)
        {
            _context = context;
        }





        [HttpPost("LoginByAdmin")]
        public async Task<ActionResult> LoginByAdmin([FromBody] Admin model)
        {
            if (model == null)
                return BadRequest("Invalid login data.");

            var admin = await _context.admin.FirstOrDefaultAsync(a => a.UserName == model.UserName);

            if (admin == null)
                return Unauthorized("Invalid username or password.");

            var passwordhasher = new PasswordHasher<Admin>();

            string hashedpassword = passwordhasher.VerifyHashedPassword(admin, admin.Password, model.Password).ToString();
             
            if (hashedpassword == "Failed")
            {
                return BadRequest("Invalid Password ");

            }



                return Ok(new { Message = "Admin login successful", Admin = admin });
        }







        [HttpGet("AllStudentEnrollments")]
        public async Task<ActionResult> GetAllStudentEnrollments()
        {
            var students = await _context.Student
                .Include(s => s.Enrollements)
                .ThenInclude(e => e.course)
                .Select(s => new
                {
                    s.StudentId,
                    StudentName = s.FullName,
                    StudentEmail = s.Email,
                    EnrolledCourses = s.Enrollements.Select(e => new
                    {
                        e.course.CourseId,
                        e.course.CourseName,
                        e.course.Capacity,
                        EnrolledCount = e.course.Enrollements.Count(),
                        AvailableSeats = e.course.Capacity - e.course.Enrollements.Count()
                    })
                }).ToListAsync();

            if (!students.Any())
                return NotFound("No enrollments found.");

            return Ok(students);
        }





        [HttpGet("EnrolledStudentsByCourseId/{courseId:int}")]
        public async Task<ActionResult> GetEnrolledStudentsByCourseId(int courseId)
        {
            var course = await _context.Course
                .Include(c => c.Enrollements)
                .ThenInclude(e => e.student)
                .FirstOrDefaultAsync(c => c.CourseId == courseId);

            if (course == null)
                return NotFound("Course not found.");

            var students = course.Enrollements.Select(e => new
            {
                e.student.StudentId,
                e.student.FullName,
                e.student.Email,
                e.student.Phone,
                EnrolledOn = e.student.datetime,
            }).ToList();

            int enrolledCount = course.Enrollements.Count();
            int availableSeats = course.Capacity - enrolledCount;

            if (students.Count == 0)
                return Ok(new
                {
                    Course = course.CourseName,
                    Capacity = course.Capacity,
                    EnrolledCount = enrolledCount,
                    AvailableSeats = availableSeats,
                    Message = "No students enrolled for this course yet."
                });

            return Ok(new
            {
                Course = course.CourseName,
                Capacity = course.Capacity,
                EnrolledCount = enrolledCount,
                AvailableSeats = availableSeats,
                TotalStudents = students.Count,
                Students = students
            });
        }






        [HttpGet("AllStudents")]
        public async Task<ActionResult<IEnumerable<Student>>> GetAllStudents()
        {
            var students = await _context.Student.ToListAsync();
            return Ok(students);
        }



        [HttpPut("Update/{id:int}")]
        public async Task<ActionResult> UpdateStudent(int id, [FromBody] Student model)
        {
            if (id <= 0)
                return BadRequest("Invalid ID.");

            var existing = await _context.Student.FindAsync(id);

            if (existing == null)
                return NotFound("Student not found.");

            existing.FullName = model.FullName;
            existing.Email = model.Email;
            existing.Phone = model.Phone;
            existing.Password = model.Password;

            _context.Student.Update(existing);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Student updated successfully", Student = existing });
        }



        [HttpDelete("Delete/{id:int}")]
        public async Task<ActionResult> DeleteStudent(int id)
        {
            if (id <= 0)
                return BadRequest("Invalid ID.");

            var student = await _context.Student.FindAsync(id);
            if (student == null)
                return NotFound("Student not found.");

            _context.Student.Remove(student);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Student deleted successfully", DeletedStudent = student });
        }

        [HttpGet]
        [Route("ByEmail/{email}")]

        public async Task<ActionResult<Student>> getByData(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest();
            }
            var details =  _context.Student.Where(n => n.Email.Equals(email));
            if (details == null)
            {
                return NotFound();
            }
            return Ok(details);
        }
    }
}
