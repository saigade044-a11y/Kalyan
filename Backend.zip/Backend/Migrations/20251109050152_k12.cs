﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UseCaseFinalSubmission.Migrations
{
    /// <inheritdoc />
    public partial class k12 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "Student Table",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "Admin Table",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "Admin Table",
                keyColumn: "AdminId",
                keyValue: 1,
                column: "Role",
                value: "Admin");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Role",
                table: "Student Table");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "Admin Table");
        }
    }
}
