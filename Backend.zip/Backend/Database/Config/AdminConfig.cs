﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UseCaseFinalSubmission.Models;

namespace UseCaseFinalSubmission.Database.Config
{
    public class AdminConfig : IEntityTypeConfiguration<Admin>
    {
        public void Configure(EntityTypeBuilder<Admin> builder)
        {
            builder.ToTable("Admin Table");

            builder.Property(n => n.AdminId).UseIdentityColumn();

            builder.Property(n => n.UserName).HasMaxLength(50).IsRequired();

            builder.Property(n => n.Password).HasMaxLength(50).IsRequired();

            Admin obj = new Admin()
            {
                AdminId = 1,
                UserName = "Praveen"
            };

            var passwordhasher = new PasswordHasher<Admin>();

            obj.Password = passwordhasher.HashPassword(obj, "Praveen@123");

            builder.HasData(obj);


        }
    }
}
